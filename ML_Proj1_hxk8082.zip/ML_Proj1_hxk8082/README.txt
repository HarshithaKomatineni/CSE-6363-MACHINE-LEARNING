Name:Harshitha Komattineni
UTA iD:1001968082
Application Used : Jupyter Notebook
Language used : python 


Libraries used : numpy , pandas , Sklearn , matpllotlib , seaborn , warnings , sklearn .

Input Files  :iris.data 

Program file : iris.ipynb 
 
You need to change the path of the data set to execute it on your system.
I have used Jupyter notebook . Open Jupyter notebook , Run the cell .

Steps to execute:
1) Extract the folder from the zip file
2) open the .ipynb in any ide or in jupyter notebook.
3)Run individual cells .

Output :

8.763157894736842
cross validation score for 2 comparisions: 8.76 (+/- 0.00)
8.078947368421053
cross validation score for 3 comparisions: 8.08 (+/- 0.00)
7.815789473684211
cross validation score for 4 comparisions: 7.82 (+/- 0.00)
7.368421052631579
cross validation score for 5 comparisions: 7.37 (+/- 0.00)
7.052631578947368
cross validation score for 6 comparisions: 7.05 (+/- 0.00)
6.631578947368421
cross validation score for 7 comparisions: 6.63 (+/- 0.00)
6.394736842105263
cross validation score for 8 comparisions: 6.39 (+/- 0.00)
6.0
cross validation score for 9 comparisions: 6.00 (+/- 0.00)
